﻿namespace MyBox
{
	public class MyCommonConstants
	{
		public static readonly System.Random SystemRandom = new System.Random();
	}
}
