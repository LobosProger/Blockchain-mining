﻿using UnityEngine;

namespace MyBox.Internal
{
	public class MyBoxStartupAsset : ScriptableObject { }
}