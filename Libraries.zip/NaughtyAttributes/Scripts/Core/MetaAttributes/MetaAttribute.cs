﻿using System;

namespace NaughtyAttributes
{
	public class MetaAttribute : Attribute, INaughtyAttribute
	{
	}
}
